const datareducer = (state=data,action)=>{

    switch(action.type){
        case 'GETDATE':
            return data
        default:
            return state;
        
    }
}

export default datareducer;