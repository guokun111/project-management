const getDate=(list)=>{
    return (dispatch)=>{
        let url = 'https://www.fastmock.site/mock/0d815e045cafd073265a4e6550ad2c9c/_xinlang-01/onePart';
        fetch(url)
        .then(res => res.json())
        .then(res => {
            dispatch({
                type:'GETDATE',
                list:res
            })
        })
    }
}