import Mock from 'mockjs2'
import { builder, getQueryParameters } from '../util'

const totalCount = 5701

const serverList = (options) => {
  const parameters = getQueryParameters(options)

  const result = []
  const pageNo = parseInt(parameters.pageNo)
  const pageSize = parseInt(parameters.pageSize)
  const totalPage = Math.ceil(totalCount / pageSize)
  const key = (pageNo - 1) * pageSize
  const next = (pageNo >= totalPage ? (totalCount % pageSize) : pageSize) + 1

  for (let i = 1; i < next; i++) {
    const tmpKey = key + i
    result.push({
      key: tmpKey,
      id: tmpKey,
      no: 'No ' + tmpKey,
      description: '这是一段描述',
      callNo: Mock.mock('@integer(1, 999)'),
      status: Mock.mock('@integer(0, 3)'),
      updatedAt: Mock.mock('@datetime'),
      editable: false
    })
  }

  return builder({
    pageSize: pageSize,
    pageNo: pageNo,
    totalCount: totalCount,
    totalPage: totalPage,
    data: result
  })
}

const projects = () => {
  return builder({
    'data': [{
      id: 1,
      cover: 'https://tvax3.sinaimg.cn/crop.0.0.1080.1080.180/884f7263ly8gdi7ptm8y4j20u00u0myq.jpg?KID=imgbed,tva&Expires=1607336732&ssig=F3WDx5IJN%2F',
      title: '人民网',
      description: '#中国学校结核病防控指南#',
      status: 1,
      updatedAt: '2020-12-07 11:48:00'
    },
    {
      id: 2,
      cover: 'https://tvax2.sinaimg.cn/crop.18.21.500.500.50/60718250ly1fe7kog3jroj20f00f03zj.jpg?KID=imgbed,tva&Expires=1607338079&ssig=5U%2FPxE8qOg',
      title: '头条新闻',
      description: '#女婴坠楼受伤父亲拒绝治疗#',
      status: 1,
      updatedAt: '2020-12-07 15:46:00'
    },
    {
      id: 3,
      cover: 'https://tvax1.sinaimg.cn/crop.0.0.1080.1080.50/002TLsr9ly8gk0aztvfa4j60u00u0gng02.jpg?KID=imgbed,tva&Expires=1607338143&ssig=uAgSLiChXo',
      title: '央视新闻',
      description: '上海6例本土确诊溯源结果',
      status: 1,
      updatedAt: '2020-12-07 15:40:00'
    },
    {
      id: 4,
      cover: 'https://tvax1.sinaimg.cn/crop.0.0.996.996.50/6486a91aly8gdi6f4f2ytj20ro0rojrt.jpg?KID=imgbed,tva&Expires=1607338284&ssig=bfRTE7Y2Gz',
      title: '环球网',
      description: '印尼总统：已收到首批来自中国的120万剂新冠疫苗',
      status: 1,
      updatedAt: '2020-12-07 15:23:00'
    },
    {
      id: 5,
      cover: 'https://tvax3.sinaimg.cn/crop.0.0.1080.1080.50/7ad6e415ly8gdi616m0ezj20u00u041b.jpg?KID=imgbed,tva&Expires=1607338205&ssig=WqTxLyew0e',
      title: '中国足球报道',
      description: '大学女足省赛因染发球员过多被判负',
      status: 1,
      updatedAt: '2020-12-07 15:37:00'
    },
    {
      id: 6,
      cover: 'https://tvax1.sinaimg.cn/crop.11.10.275.275.50/005vnhZYly8ftjmwo0bx4j308c08cq32.jpg?KID=imgbed,tva&Expires=1607338353&ssig=13DvM72tP3',
      title: '澎湃新闻',
      description: '辛巴团队回应燕窝赔付',
      status: 1,
      updatedAt: '2020-12-07 13:16:00'
    }
    ],
    'pageSize': 10,
    'pageNo': 0,
    'totalPage': 6,
    'totalCount': 57
  })
}

const activity = () => {
  return builder([{
    id: 1,
    user: {
      nickname: '环球时报',
      avatar: 'https://tvax1.sinaimg.cn/crop.0.0.1080.1080.50/75b1a75fly8gdi6mfzlthj20u00u0gn5.jpg?KID=imgbed,tva&Expires=1607338607&ssig=Od9yut5NQd'
    },
    project: {
      name: '新浪微博',
      action: '更新',
      event: '韩国总统文在寅向国民致歉'
    },
    time: '2020-12-07 14:15:00'
  },
  {
    id: 1,
    user: {
      nickname: '新浪娱乐',
      avatar: 'https://tvax2.sinaimg.cn/crop.0.0.1080.1080.50/61e7f4aaly8gdi964yxtkj20u00u0q5e.jpg?KID=imgbed,tva&Expires=1607338826&ssig=MXAha1PnGY'
    },
    project: {
      name: '新浪微博',
      action: '更新',
      event: '素媛案罪犯一小时可做1000个俯卧撑'
    },
    time: '2020-12-07 09:35:37'
  },
  {
    id: 1,
    user: {
      nickname: '环球时报',
      avatar: 'https://tvax1.sinaimg.cn/crop.0.0.1080.1080.50/75b1a75fly8gdi6mfzlthj20u00u0gn5.jpg?KID=imgbed,tva&Expires=1607338607&ssig=Od9yut5NQd'
    },
    project: {
      name: '新浪微博',
      action: '上传',
      event: '时代周刊称2020是最糟糕的一年'
    },
    time: '2020-12-06 17:30:00'
  },
  {
    id: 1,
    user: {
      nickname: '头条新闻',
      avatar: 'https://tvax2.sinaimg.cn/crop.18.21.500.500.50/60718250ly1fe7kog3jroj20f00f03zj.jpg?KID=imgbed,tva&Expires=1607339007&ssig=7uEiyDAQ8H'
    },
    project: {
      name: '新浪微博',
      action: '更新',
      event: '云南新版艾滋病防治条例'
    },
    time: '2020-12-07 13:31:00'
  },
  {
    id: 1,
    user: {
      nickname: '环球时报',
      avatar: 'https://tvax1.sinaimg.cn/crop.0.0.1080.1080.50/75b1a75fly8gdi6mfzlthj20u00u0gn5.jpg?KID=imgbed,tva&Expires=1607338607&ssig=Od9yut5NQd'
    },
    project: {
      name: '新浪微博',
      action: '上传',
      event: '美国男子因新冠病毒三周内失去四位至亲'
    },
    time: '2020-12-06 18:30:00'
  },
  {
    id: 1,
    user: {
      nickname: '头条新闻',
      avatar: 'https://tvax2.sinaimg.cn/crop.18.21.500.500.50/60718250ly1fe7kog3jroj20f00f03zj.jpg?KID=imgbed,tva&Expires=1607339007&ssig=7uEiyDAQ8H'
    },
    project: {
      name: '新浪微博',
      action: '上传',
      event: '专家称延迟退休男女同龄为好'
    },
    time: '2020-12-07 08:41:00'
  }
  ])
}

const teams = () => {
  return builder([{
    id: 1,
    name: '郭坤',
    avatar: 'https://gw.alipayobjects.com/zos/rmsportal/BiazfanxmamNRoxxVxka.png'
  },
  {
    id: 2,
    name: '张婷',
    avatar: 'https://gw.alipayobjects.com/zos/rmsportal/cnrhVkzwxjPwAaCfPbdc.png'
  },
  {
    id: 1,
    name: '叶烁',
    avatar: 'https://gw.alipayobjects.com/zos/rmsportal/gaOngJwsRYRaVAuXXcmB.png'
  }
  // {
  //   id: 1,
  //   name: '中二少女团',
  //   avatar: 'https://gw.alipayobjects.com/zos/rmsportal/ubnKSIfAJTxIgXOKlciN.png'
  // },
  // {
  //   id: 1,
  //   name: '骗你学计算机',
  //   avatar: 'https://gw.alipayobjects.com/zos/rmsportal/WhxKECPNujWoWEFNdnJE.png'
  // }
  ])
}

const radar = () => {
  return builder([
    {
      item: '体育财经',
      '轻度舆情': 43,
      '中度舆情': 32,
      '重度舆情': 25
    },
  {
    item: '时事',
    '轻度舆情': 43,
    '中度舆情': 39,
    '重度舆情': 18
  },
  {
    item: '综艺',
    '轻度舆情': 21,
    '中度舆情': 32,
    '重度舆情': 47
  },
  {
    item: '社会',
    '轻度舆情': 27,
    '中度舆情': 46,
    '重度舆情': 27
  },
  {
    item: '搞笑',
    '轻度舆情': 68,
    '中度舆情': 29,
    '重度舆情': 3
  },
  {
    item: '体育财经',
    '轻度舆情': 43,
    '中度舆情': 32,
    '重度舆情': 25
  }
  ])
}

Mock.mock(/\/service/, 'get', serverList)
Mock.mock(/\/list\/search\/projects/, 'get', projects)
Mock.mock(/\/workplace\/activity/, 'get', activity)
Mock.mock(/\/workplace\/teams/, 'get', teams)
Mock.mock(/\/workplace\/radar/, 'get', radar)
